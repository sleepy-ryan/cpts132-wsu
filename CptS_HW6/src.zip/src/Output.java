import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Output extends JFrame {

    int size = 19;
    boolean cellsMap[][];
    JButton cells[][];

    public Output(){
        Random random = new Random();

        cellsMap = new boolean[size][size];
        cells = new JButton[size][size];
        setSize(400,400);
        setLayout(new GridLayout(size,size));

        //generate board with random cells
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < 19; j++) {
                cellsMap[i][j] = random.nextInt(38)<11;
                JButton temp = new JButton();
                if(cellsMap[i][j]){
                    temp.setBackground(Color.BLACK);
                }
                else{
                    temp.setBackground(Color.LIGHT_GRAY);
                }
                add(temp);
                cells[i][j] = temp;
            }
        }

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Timer timer = new Timer(38, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                boolean[][] temp = new boolean[size][size];

                for (int i = 0; i < size; i++) {
                    for (int j = 0; j < 19; j++) {
                        int count = countNeighbors(i,j);

                        if(cellsMap[i][j]) {
                            if(count < 2){
                                temp[i][j]=false;
                            }

                            if(count == 3 || count ==2){
                                temp[i][j]=true;
                            }

                            if(count > 3){
                                temp[i][j]=false;
                            }

                        }
                        else {
                            if (count == 3){
                                temp[i][j]=true;
                            }
                        }
                    }
                }

                cellsMap = temp;

                for (int i = 0; i < size; i++) {
                    for (int j = 0; j < 19; j++) {
                        if(cellsMap[i][j]){
                            cells[i][j].setBackground(Color.BLACK);
                        }
                        else {
                            cells[i][j].setBackground(Color.WHITE);
                        }
                    }
                }

            }
        });

        timer.start();
    }

    int countNeighbors(int x, int y){
        int count = 0;

        for (int i = x-1; i <= x+1; i++) {
            for (int j = y-1; j <= y+1; j++) {

                try{
                    if(cellsMap[i][j]){
                        count++;
                    }
                }catch(Exception e){

                }

            }
        }

        if(cellsMap[x][y]){
            count--;
        }
        return count;
    }
    
    
    public static void main(String[] args) {
        new Output();
    }
}