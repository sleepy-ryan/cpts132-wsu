
public class Board {
    int width;
    int height;

    int[][] board;

    public Board(int width, int height) {
        this.width = width;
        this.height = height;

        this.board = new int[width][height];
    }

    public void printBoard(){
        for (int y = 0; y < height; y++) {
            String line = "|";
            for (int x = 0; x < width; x++) {
                if (this.board[x][y] == 0){
                    line+= "X";
                }
                else {
                    line+="O";
                }
            }
            line+= "|";
            System.out.println(line);
        }
        System.out.println("----------\n");
    }

    public void setAlive(int x, int y){
        this.board[x][y] = 1;
    }

    public void setDead(int x, int y){
        this.board[x][y] = 0;
    }

    public int countAlive(int x, int y){
        int count =0;

        count += getCellState(x - 1,y - 1);
        count += getCellState(x,y - 1);
        count += getCellState(x + 1,y - 1);

        count += getCellState(x - 1,y);
        count += getCellState(x + 1,y);

        count += getCellState(x - 1,y + 1);
        count += getCellState(x,y + 1);
        count += getCellState(x + 1,y + 1);

        return count;
    }

    public int getCellState(int x, int y){
        if(x < 0 || x >= width){
            return 0;
        }
        if (y < 0 || y >= height){
            return 0;
        }
        return this.board[x][y];
    }

    public void nextGeneration(){
        int[][] newBoard = new int[width][height];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int aliveNeighbors = countAlive(x,y);

                if(getCellState(x,y)==1){

                    if(aliveNeighbors < 2){
                        newBoard[x][y] = 0;
                    }

                    else if(aliveNeighbors == 2 || aliveNeighbors == 3) {
                        newBoard[x][y] = 1;
                    }

                    else if(aliveNeighbors > 3){
                        newBoard[x][y] = 0;
                    }
                }
                else {

                    if(aliveNeighbors == 3){
                        newBoard[x][y] = 1;
                    }
                }
            }
        }
        this.board = newBoard;
    }

    public static void main(String[] args) {
        Board gameBoard = new Board(8,5);

        gameBoard.setAlive(2,2);
        gameBoard.setAlive(3,2);
        gameBoard.setAlive(4,2);

        gameBoard.printBoard();

        gameBoard.nextGeneration();

        gameBoard.printBoard();

        gameBoard.nextGeneration();

        gameBoard.printBoard();
    }
}
