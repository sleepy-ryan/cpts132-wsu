import java.io.*;
import java.util.Arrays;
import java.util.Comparator;

public class WriteToFile {


    private static President[] presidentList = new President[200];

    static int index = 0;

    public static void main(String[] args) {


        String outputFile = "same_order.txt";

        String lastNameOutputFile = "last_name.txt";

        try {


            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

            BufferedWriter writerLast = new BufferedWriter(new FileWriter(lastNameOutputFile));

            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\sayth\\IdeaProjects\\CptS_HW13\\presidents.txt"));

            String line;


            while ((line = br.readLine()) != null) {


                writeToFile(line, writer);

            }

            br.close();

            writer.close();


            sortList(writerLast);

            writerLast.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public static void writeToFile(String line, BufferedWriter writer) {


        String[] tokens = line.split("\t");


        President p = new President(tokens[1], tokens[0], tokens[2], tokens[3]);


        presidentList[index] = p;


        index++;


        String outputLine = tokens[1] + " " + tokens[0] + " was president from " +

                tokens[2] + " to " + tokens[3] + ".";

        try {

            writer.append(outputLine);

            writer.append(System.lineSeparator());

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

    public static void sortList(BufferedWriter writerLast) {


        Arrays.sort(presidentList, 0, index, new Comparator<President>() {

            @Override

            public int compare(President p1, President p2) {


                if (p1.getLastName().compareTo(p2.getLastName()) == 0) {

                    if (p1.getFirstName().compareTo(p2.getFirstName()) == 0) {

                        return p1.getStartDate().compareTo(p2.getStartDate());

                    }

                    return p1.getFirstName().compareTo(p2.getFirstName());

                }

                return p1.getLastName().compareTo(p2.getLastName());

            }

        });

        try {


            for (int i = 0; i < index; i++) {


                String outputLine = presidentList[i].getFirstName() + " " + presidentList[i].getLastName() + " was president from " +

                        presidentList[i].getStartDate() + " to " + presidentList[i].getEndDate() + ".";

                writerLast.append(outputLine);

                writerLast.append(System.lineSeparator());

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

}