public class President {


    private String firstName, lastName;

    private String startDate, endDate;


    public President(String firstName, String lastName, String startDate, String endDate) {

        this.firstName = firstName;

        this.lastName = lastName;

        this.startDate = startDate;

        this.endDate = endDate;

    }


    public String getFirstName() {

        return firstName;

    }

    public String getLastName() {

        return lastName;

    }

    public String getStartDate() {

        return startDate;

    }

    public String getEndDate() {

        return endDate;

    }

}